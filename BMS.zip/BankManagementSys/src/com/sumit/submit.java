package com.sumit;

import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/submit")
public class submit extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		try{
			HttpSession session =request.getSession();
			String ac=(String)session.getAttribute("acc");
			String feed=request.getParameter("feedback");
			String user=(String)session.getAttribute("username");
			String sql="insert into feedback(feedback,uname,acc_num) values (?,?,?)";
			String url="jdbc:mysql://localhost:3306/login";
			String username="root";
			String password="pass";	
			Connection connection = null;
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(url,username,password);
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setString(1,feed);
			statement.setString(2,user);
			statement.setString(3,ac);
		 	statement.executeUpdate();
		 	connection.close();
		} catch (Exception e) {
		e.printStackTrace();
		}
		
		
		response.sendRedirect("submit.jsp");
		
		
	}

}
