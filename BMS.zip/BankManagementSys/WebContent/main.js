function registration()
	{
		var name= document.getElementById("uname").value;
		var pwd= document.getElementById("pass").value;
		if(name=='')
		{
			alert('Please enter your name');
		}
		else if(pwd=='')
		{
			alert('Please enter Password');
		}
		else
		{				                            
               alert('Thank You for Login & You are Redirecting');

			   window.location = "accountbal.jsp"; 
		}
	}